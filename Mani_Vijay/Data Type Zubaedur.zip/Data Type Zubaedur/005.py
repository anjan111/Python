# wap read  any data from input and convert float  only

def main():
    num =input("enter some data ")
    num =float(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

# above code  run 9 time with 9 different datatypes 
