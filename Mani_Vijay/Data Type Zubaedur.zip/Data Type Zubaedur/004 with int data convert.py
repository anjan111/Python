
## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()
## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

    ## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

    ## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

    ## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

    ## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

    ## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()

    ## wap read  any data from input and convert int only

def main():
    num =input("enter some data ")
    num =int(num)
    print " num  = ",num
    print "type is ", type(num)
    print "id   is ",id(num)

if(__name__ == "__main__"):
    main()
