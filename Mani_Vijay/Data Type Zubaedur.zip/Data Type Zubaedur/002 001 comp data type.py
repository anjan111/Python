
# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = str(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = list(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = tuple(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = set(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

