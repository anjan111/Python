# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = int(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = float(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = complex(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = bool(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()

# wap addition of two numbers using raw_input functions 

def main( ):
    var = raw_input("enter some data")
    var = NoneType(var)
    print "var = ",var
    print " type of var ",type(var)
    print " id of var ",id(var)

if(__name__ == "__main__"):
        main()


